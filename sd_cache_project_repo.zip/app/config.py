from dataclasses import dataclass
import os

@dataclass(frozen=True)
class Settings:
    redis_host: str = os.getenv("REDIS_HOST", "localhost")
    redis_port: int = int(os.getenv("REDIS_PORT", "6379"))
    cache_ttl: int = int(os.getenv("CACHE_TTL", "60"))
    cache_size_mb: int = int(os.getenv("CACHE_SIZE_MB", "200"))
    cache_policy: str = os.getenv("CACHE_POLICY", "allkeys-lru")
    data_path: str = os.getenv("DATA_PATH", "data/buildings_sample.csv")
    metrics_path: str = os.getenv("METRICS_PATH", "results/metrics_log.csv")

settings = Settings()
