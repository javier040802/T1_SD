from __future__ import annotations

import random
from dataclasses import dataclass
import numpy as np

ZONES = ["Z1", "Z2", "Z3", "Z4", "Z5"]

@dataclass
class QuerySpec:
    query_type: str
    zone: str
    params: dict

def zipf_zone(rng: np.random.Generator, a: float = 2.0) -> str:
    while True:
        n = int(rng.zipf(a))
        if 1 <= n <= len(ZONES):
            return ZONES[n - 1]

def uniform_zone(rng: np.random.Generator) -> str:
    return random.choice(ZONES)

def generate_query(rng: np.random.Generator, distribution: str = "zipf") -> QuerySpec:
    zone_picker = zipf_zone if distribution == "zipf" else uniform_zone
    qtype = random.choice(["Q1", "Q2", "Q3", "Q4", "Q5"])
    zone = zone_picker(rng)

    if qtype in {"Q1", "Q2", "Q3"}:
        conf = random.choice([0.0, 0.2, 0.5, 0.7, 0.9])
        params = {"confidence_min": conf}
    elif qtype == "Q4":
        other = zone_picker(rng)
        params = {"zone_b": other, "confidence_min": random.choice([0.0, 0.2, 0.5, 0.7])}
    else:
        params = {"bins": random.choice([5, 8, 10])}

    return QuerySpec(query_type=qtype, zone=zone, params=params)
