from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from statistics import mean
from typing import Any
import csv
import os
import time

@dataclass
class MetricEvent:
    timestamp: float
    query_type: str
    cache_key: str
    hit: int
    latency_ms: float
    policy: str
    cache_size_mb: int
    ttl: int

class MetricsStore:
    def __init__(self, path: str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_header()
        self.events: list[MetricEvent] = []

    def _ensure_header(self) -> None:
        if not self.path.exists():
            with self.path.open("w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow([
                    "timestamp", "query_type", "cache_key", "hit",
                    "latency_ms", "policy", "cache_size_mb", "ttl"
                ])

    def log(self, event: MetricEvent) -> None:
        self.events.append(event)
        with self.path.open("a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                event.timestamp,
                event.query_type,
                event.cache_key,
                event.hit,
                round(event.latency_ms, 4),
                event.policy,
                event.cache_size_mb,
                event.ttl,
            ])

    def reset(self) -> None:
        self.events.clear()
        if self.path.exists():
            self.path.unlink()
        self._ensure_header()

    def summary(self) -> dict[str, Any]:
        total = len(self.events)
        hits = sum(e.hit for e in self.events)
        misses = total - hits
        latencies = sorted(e.latency_ms for e in self.events)

        def percentile(p: float) -> float:
            if not latencies:
                return 0.0
            idx = int(round((len(latencies) - 1) * p))
            return float(latencies[idx])

        elapsed_sec = 0.0
        if total >= 2:
            elapsed_sec = max(self.events[-1].timestamp - self.events[0].timestamp, 1e-9)

        return {
            "total_requests": total,
            "hits": hits,
            "misses": misses,
            "hit_rate": hits / total if total else 0.0,
            "miss_rate": misses / total if total else 0.0,
            "p50_ms": percentile(0.50),
            "p95_ms": percentile(0.95),
            "avg_latency_ms": mean(latencies) if latencies else 0.0,
            "throughput_req_per_sec": total / elapsed_sec if elapsed_sec > 0 else 0.0,
        }
