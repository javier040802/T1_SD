from __future__ import annotations

import numpy as np
import pandas as pd

def q1_count(df: pd.DataFrame, confidence_min: float = 0.0) -> int:
    return int((df["confidence"] >= confidence_min).sum())

def q2_area(df: pd.DataFrame, confidence_min: float = 0.0) -> dict:
    filtered = df[df["confidence"] >= confidence_min]
    n = int(len(filtered))
    if n == 0:
        return {"avg_area": 0.0, "total_area": 0.0, "n": 0}
    return {
        "avg_area": float(filtered["area_in_meters"].mean()),
        "total_area": float(filtered["area_in_meters"].sum()),
        "n": n,
    }

def q3_density(df: pd.DataFrame, area_km2: float, confidence_min: float = 0.0) -> float:
    count = q1_count(df, confidence_min=confidence_min)
    return float(count / area_km2) if area_km2 else 0.0

def q4_compare(density_a: float, density_b: float, zone_a: str, zone_b: str) -> dict:
    winner = zone_a if density_a >= density_b else zone_b
    return {
        "zone_a": zone_a,
        "zone_b": zone_b,
        "density_a": density_a,
        "density_b": density_b,
        "winner": winner,
    }

def q5_confidence_dist(df: pd.DataFrame, bins: int = 5) -> list[dict]:
    scores = df["confidence"].to_numpy()
    counts, edges = np.histogram(scores, bins=bins, range=(0.0, 1.0))
    return [
        {
            "bucket": int(i),
            "min": float(edges[i]),
            "max": float(edges[i + 1]),
            "count": int(counts[i]),
        }
        for i in range(bins)
    ]
