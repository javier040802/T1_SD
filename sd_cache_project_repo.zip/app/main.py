from __future__ import annotations

from pathlib import Path
import time
import os
import random

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse

from app.cache import RedisCache
from app.config import settings
from app.data_loader import ZONES, ZONE_AREA_KM2, load_dataset, split_by_zone
from app.metrics import MetricEvent, MetricsStore
from app.queries import q1_count, q2_area, q3_density, q4_compare, q5_confidence_dist

app = FastAPI(
    title="Plataforma de análisis de preguntas y respuestas",
    version="1.0.0"
)

df = load_dataset(settings.data_path)
data_by_zone = split_by_zone(df)

cache = RedisCache(settings.redis_host, settings.redis_port, ttl=settings.cache_ttl)
metrics = MetricsStore(settings.metrics_path)

def _cache_key_q1(zone: str, confidence_min: float) -> str:
    return f"count:{zone}:conf={confidence_min:.3f}"

def _cache_key_q2(zone: str, confidence_min: float) -> str:
    return f"area:{zone}:conf={confidence_min:.3f}"

def _cache_key_q3(zone: str, confidence_min: float) -> str:
    return f"density:{zone}:conf={confidence_min:.3f}"

def _cache_key_q4(zone_a: str, zone_b: str, confidence_min: float) -> str:
    ordered = sorted([zone_a, zone_b])
    return f"compare:density:{ordered[0]}:{ordered[1]}:conf={confidence_min:.3f}"

def _cache_key_q5(zone: str, bins: int) -> str:
    return f"confidence_dist:{zone}:bins={bins}"

def _record(query_type: str, cache_key: str, hit: bool, latency_ms: float):
    metrics.log(
        MetricEvent(
            timestamp=time.time(),
            query_type=query_type,
            cache_key=cache_key,
            hit=1 if hit else 0,
            latency_ms=latency_ms,
            policy=settings.cache_policy,
            cache_size_mb=settings.cache_size_mb,
            ttl=settings.cache_ttl,
        )
    )

@app.get("/health")
def health():
    return {
        "status": "ok",
        "zones_loaded": list(data_by_zone.keys()),
        "rows": int(len(df)),
    }

@app.get("/q1")
def endpoint_q1(zone: str, confidence_min: float = 0.0):
    if zone not in data_by_zone:
        raise HTTPException(status_code=400, detail="Zona inválida")
    key = _cache_key_q1(zone, confidence_min)
    result = cache.get_or_set(
        key,
        lambda: q1_count(data_by_zone[zone], confidence_min=confidence_min)
    )
    _record("Q1", key, result.hit, result.latency_ms)
    return {"query": "Q1", "zone": zone, "confidence_min": confidence_min, "result": result.value, "hit": result.hit, "latency_ms": result.latency_ms}

@app.get("/q2")
def endpoint_q2(zone: str, confidence_min: float = 0.0):
    if zone not in data_by_zone:
        raise HTTPException(status_code=400, detail="Zona inválida")
    key = _cache_key_q2(zone, confidence_min)
    result = cache.get_or_set(
        key,
        lambda: q2_area(data_by_zone[zone], confidence_min=confidence_min)
    )
    _record("Q2", key, result.hit, result.latency_ms)
    return {"query": "Q2", "zone": zone, "confidence_min": confidence_min, "result": result.value, "hit": result.hit, "latency_ms": result.latency_ms}

@app.get("/q3")
def endpoint_q3(zone: str, confidence_min: float = 0.0):
    if zone not in data_by_zone:
        raise HTTPException(status_code=400, detail="Zona inválida")
    key = _cache_key_q3(zone, confidence_min)
    result = cache.get_or_set(
        key,
        lambda: q3_density(data_by_zone[zone], area_km2=ZONE_AREA_KM2[zone], confidence_min=confidence_min)
    )
    _record("Q3", key, result.hit, result.latency_ms)
    return {"query": "Q3", "zone": zone, "confidence_min": confidence_min, "result": result.value, "hit": result.hit, "latency_ms": result.latency_ms}

@app.get("/q4")
def endpoint_q4(zone_a: str, zone_b: str, confidence_min: float = 0.0):
    if zone_a not in data_by_zone or zone_b not in data_by_zone:
        raise HTTPException(status_code=400, detail="Zona inválida")
    key = _cache_key_q4(zone_a, zone_b, confidence_min)
    result = cache.get_or_set(
        key,
        lambda: q4_compare(
            q3_density(data_by_zone[zone_a], area_km2=ZONE_AREA_KM2[zone_a], confidence_min=confidence_min),
            q3_density(data_by_zone[zone_b], area_km2=ZONE_AREA_KM2[zone_b], confidence_min=confidence_min),
            zone_a,
            zone_b,
        )
    )
    _record("Q4", key, result.hit, result.latency_ms)
    return {"query": "Q4", "zone_a": zone_a, "zone_b": zone_b, "confidence_min": confidence_min, "result": result.value, "hit": result.hit, "latency_ms": result.latency_ms}

@app.get("/q5")
def endpoint_q5(zone: str, bins: int = 5):
    if zone not in data_by_zone:
        raise HTTPException(status_code=400, detail="Zona inválida")
    if bins < 1:
        raise HTTPException(status_code=400, detail="bins debe ser mayor o igual a 1")
    key = _cache_key_q5(zone, bins)
    result = cache.get_or_set(
        key,
        lambda: q5_confidence_dist(data_by_zone[zone], bins=bins)
    )
    _record("Q5", key, result.hit, result.latency_ms)
    return {"query": "Q5", "zone": zone, "bins": bins, "result": result.value, "hit": result.hit, "latency_ms": result.latency_ms}

@app.get("/metrics/summary")
def metrics_summary():
    return metrics.summary()

@app.post("/metrics/reset")
def metrics_reset():
    metrics.reset()
    cache.flush()
    return {"status": "reset"}

@app.get("/zones")
def zones():
    return {
        zone_id: {
            "name": payload["name"],
            "area_km2": ZONE_AREA_KM2[zone_id],
            **payload,
            "rows": int(len(data_by_zone[zone_id])),
        }
        for zone_id, payload in ZONES.items()
    }
