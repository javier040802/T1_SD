from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any, Callable

import redis

@dataclass
class CacheResult:
    value: Any
    hit: bool
    latency_ms: float

class RedisCache:
    def __init__(self, host: str, port: int, ttl: int = 60):
        self.client = redis.Redis(host=host, port=port, decode_responses=True)
        self.ttl = ttl

    def get_or_set(self, key: str, producer: Callable[[], Any]) -> CacheResult:
        start = time.perf_counter()

        try:
            cached = self.client.get(key)
            if cached is not None:
                elapsed_ms = (time.perf_counter() - start) * 1000
                return CacheResult(value=json.loads(cached), hit=True, latency_ms=elapsed_ms)

            value = producer()
            self.client.setex(key, self.ttl, json.dumps(value))
            elapsed_ms = (time.perf_counter() - start) * 1000
            return CacheResult(value=value, hit=False, latency_ms=elapsed_ms)
        except redis.RedisError:
            # Fallback seguro: si Redis no está disponible, el sistema sigue respondiendo.
            value = producer()
            elapsed_ms = (time.perf_counter() - start) * 1000
            return CacheResult(value=value, hit=False, latency_ms=elapsed_ms)

    def flush(self) -> None:
        try:
            self.client.flushdb()
        except redis.RedisError:
            pass
