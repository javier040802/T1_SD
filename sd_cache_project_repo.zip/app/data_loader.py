from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import pandas as pd
import numpy as np

ZONES = {
    "Z1": {"name": "Providencia", "lat_min": -33.445, "lat_max": -33.420, "lon_min": -70.640, "lon_max": -70.600},
    "Z2": {"name": "Las Condes", "lat_min": -33.420, "lat_max": -33.390, "lon_min": -70.600, "lon_max": -70.550},
    "Z3": {"name": "Maipú", "lat_min": -33.530, "lat_max": -33.490, "lon_min": -70.790, "lon_max": -70.740},
    "Z4": {"name": "Santiago Centro", "lat_min": -33.460, "lat_max": -33.430, "lon_min": -70.670, "lon_max": -70.630},
    "Z5": {"name": "Pudahuel", "lat_min": -33.470, "lat_max": -33.430, "lon_min": -70.810, "lon_max": -70.760},
}

# Bounding-box area approximation in km² (for density).
ZONE_AREA_KM2 = {
    "Z1": 12.0,
    "Z2": 18.0,
    "Z3": 30.0,
    "Z4": 12.0,
    "Z5": 20.0,
}

def _random_points_for_zone(zone_id: str, n: int, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed + abs(hash(zone_id)) % 1000)
    z = ZONES[zone_id]
    return pd.DataFrame({
        "latitude": rng.uniform(z["lat_min"], z["lat_max"], n),
        "longitude": rng.uniform(z["lon_min"], z["lon_max"], n),
        "area_in_meters": rng.lognormal(mean=4.0, sigma=0.5, size=n),
        "confidence": rng.uniform(0.0, 1.0, n),
        "zone_id": zone_id,
    })

def generate_sample_dataset(path: str, seed: int = 42) -> pd.DataFrame:
    path_obj = Path(path)
    path_obj.parent.mkdir(parents=True, exist_ok=True)

    frames = []
    for zone_id, n in {"Z1": 3000, "Z2": 3200, "Z3": 2800, "Z4": 2600, "Z5": 2400}.items():
        frames.append(_random_points_for_zone(zone_id, n=n, seed=seed))

    df = pd.concat(frames, ignore_index=True)
    df.to_csv(path_obj, index=False)
    return df

def load_dataset(path: str) -> pd.DataFrame:
    path_obj = Path(path)
    if not path_obj.exists():
        return generate_sample_dataset(path)

    df = pd.read_csv(path_obj)
    required = {"latitude", "longitude", "area_in_meters", "confidence"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Dataset missing columns: {sorted(missing)}")

    if "zone_id" not in df.columns:
        df = assign_zones(df)
    return df

def assign_zones(df: pd.DataFrame) -> pd.DataFrame:
    zone_ids = []
    for _, row in df.iterrows():
        assigned = None
        for zone_id, z in ZONES.items():
            if z["lat_min"] <= row["latitude"] <= z["lat_max"] and z["lon_min"] <= row["longitude"] <= z["lon_max"]:
                assigned = zone_id
                break
        zone_ids.append(assigned)
    df = df.copy()
    df["zone_id"] = zone_ids
    df = df[df["zone_id"].notna()].reset_index(drop=True)
    return df

def split_by_zone(df: pd.DataFrame) -> dict[str, pd.DataFrame]:
    data = {}
    for zone_id in ZONES:
        data[zone_id] = df[df["zone_id"] == zone_id].reset_index(drop=True)
    return data
