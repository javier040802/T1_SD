# Plataforma de análisis de preguntas y respuestas en Internet

Repositorio listo para ejecutar el Entregable 1 de Sistemas Distribuidos.

## Qué incluye
- API en FastAPI para Q1–Q5
- Caché en Redis con TTL
- Políticas configurables: LRU, LFU y FIFO
- Generador de tráfico Zipf y uniforme
- Registro de métricas a CSV
- Scripts para experimentos y análisis
- Configuración con Docker y docker-compose

## Estructura
```bash
project/
├── app/
├── data/
├── scripts/
├── report/
├── docker-compose.yml
├── Dockerfile
├── redis.conf
└── requirements.txt
```

## Requisitos
- Docker
- Docker Compose

## Levantar el sistema
```bash
docker compose up --build
```

La API quedará disponible en:

- `http://localhost:8000/docs`
- `http://localhost:8000/health`

## Endpoints principales

### Q1
```bash
GET /q1?zone=Z1&confidence_min=0.5
```

### Q2
```bash
GET /q2?zone=Z1&confidence_min=0.5
```

### Q3
```bash
GET /q3?zone=Z1&confidence_min=0.5
```

### Q4
```bash
GET /q4?zone_a=Z1&zone_b=Z2&confidence_min=0.5
```

### Q5
```bash
GET /q5?zone=Z1&bins=5
```

### Métricas
```bash
GET /metrics/summary
```

### Reset de métricas
```bash
POST /metrics/reset
```

## Experimentos
1. Levantar el sistema.
2. Correr el script de tráfico.
3. Analizar el CSV generado.

Ejemplo:
```bash
python scripts/run_experiments.py --distribution zipf --requests 1000
python scripts/analyze_results.py
```

## Datos
El repositorio trae un dataset de ejemplo sintético en `data/buildings_sample.csv` para poder ejecutar todo de inmediato. Para la entrega final, puedes reemplazarlo por el subconjunto real de Google Open Buildings filtrado a las cinco zonas del enunciado.

## Informe
La plantilla LaTeX está en `report/template.tex`.

## Video de demo
Agrega aquí tu enlace final del video.

## Repositorio
Agrega aquí el enlace público del GitHub o GitLab.
