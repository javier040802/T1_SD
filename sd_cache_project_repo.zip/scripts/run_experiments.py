from __future__ import annotations

import argparse
import random
import time
from pathlib import Path

import numpy as np
import pandas as pd
import requests

BASE_URL = "http://localhost:8000"
ZONES = ["Z1", "Z2", "Z3", "Z4", "Z5"]

def choose_zone(distribution: str, rng: np.random.Generator) -> str:
    if distribution == "zipf":
        while True:
            n = int(rng.zipf(2.0))
            if 1 <= n <= len(ZONES):
                return ZONES[n - 1]
    return random.choice(ZONES)

def call_random_endpoint(zone: str):
    q = random.choice(["Q1", "Q2", "Q3", "Q4", "Q5"])
    conf = random.choice([0.0, 0.2, 0.5, 0.7, 0.9])

    if q == "Q1":
        return requests.get(f"{BASE_URL}/q1", params={"zone": zone, "confidence_min": conf})
    if q == "Q2":
        return requests.get(f"{BASE_URL}/q2", params={"zone": zone, "confidence_min": conf})
    if q == "Q3":
        return requests.get(f"{BASE_URL}/q3", params={"zone": zone, "confidence_min": conf})
    if q == "Q4":
        zone_b = random.choice(ZONES)
        return requests.get(f"{BASE_URL}/q4", params={"zone_a": zone, "zone_b": zone_b, "confidence_min": conf})
    bins = random.choice([5, 8, 10])
    return requests.get(f"{BASE_URL}/q5", params={"zone": zone, "bins": bins})

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--distribution", choices=["zipf", "uniform"], default="zipf")
    parser.add_argument("--requests", type=int, default=500)
    parser.add_argument("--output", default="results/experiment_results.csv")
    args = parser.parse_args()

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(42)

    rows = []
    for i in range(args.requests):
        zone = choose_zone(args.distribution, rng)
        start = time.perf_counter()
        resp = call_random_endpoint(zone)
        elapsed_ms = (time.perf_counter() - start) * 1000

        try:
            payload = resp.json()
        except Exception:
            payload = {"detail": resp.text}

        rows.append({
            "i": i,
            "distribution": args.distribution,
            "zone": zone,
            "status_code": resp.status_code,
            "elapsed_ms": elapsed_ms,
            "hit": payload.get("hit"),
            "query": payload.get("query"),
            "latency_ms": payload.get("latency_ms"),
        })

    df = pd.DataFrame(rows)
    df.to_csv(args.output, index=False)
    print(df.groupby("distribution")[["elapsed_ms"]].mean())

if __name__ == "__main__":
    main()
