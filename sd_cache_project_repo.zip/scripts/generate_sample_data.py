from app.data_loader import generate_sample_dataset

if __name__ == "__main__":
    df = generate_sample_dataset("data/buildings_sample.csv")
    print(df.head())
    print(f"Rows generated: {len(df)}")
