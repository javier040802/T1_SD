from __future__ import annotations

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

INPUT = Path("results/experiment_results.csv")
OUTPUT = Path("results/summary_metrics.csv")

def main():
    if not INPUT.exists():
        raise FileNotFoundError(f"No se encontró {INPUT}")

    df = pd.read_csv(INPUT)

    summary = df.groupby("distribution").agg(
        total_requests=("i", "count"),
        hit_rate=("hit", "mean"),
        avg_elapsed_ms=("elapsed_ms", "mean"),
        p50_elapsed_ms=("elapsed_ms", lambda s: s.quantile(0.50)),
        p95_elapsed_ms=("elapsed_ms", lambda s: s.quantile(0.95)),
    )
    summary.to_csv(OUTPUT)

    ax = summary[["hit_rate"]].plot(kind="bar", legend=False)
    ax.set_title("Hit rate por distribución")
    ax.set_ylabel("Hit rate")
    plt.tight_layout()
    plt.savefig("results/hit_rate_by_distribution.png", dpi=160)
    plt.close()

    ax = summary[["p50_elapsed_ms", "p95_elapsed_ms"]].plot(kind="bar")
    ax.set_title("Latencia por distribución")
    ax.set_ylabel("ms")
    plt.tight_layout()
    plt.savefig("results/latency_by_distribution.png", dpi=160)
    plt.close()

    print(summary)

if __name__ == "__main__":
    main()
